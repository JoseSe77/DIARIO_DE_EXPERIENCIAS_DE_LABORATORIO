﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1: ");
        Console.WriteLine("\nIngrese un número entero: ");
        int entero;
        bool canConvert = int.TryParse(Console.ReadLine(), out entero);

        if (canConvert == true)
        {
            if (entero > 0)
            {
                Console.WriteLine("El número ingresado es positivo");
            }
            else if (entero < 0)
            {
                Console.WriteLine("El número ingresado es negativo");
            }
            else if (entero == 0)
            {
                Console.WriteLine("El número ingresado es cero");
            }
        } else
        {
            Console.WriteLine("El valor ingresado no es un número entero");
        }

        Console.WriteLine("\nEjercicio 2");

        Console.WriteLine("\nIngrese el número de día");
        int dia;
        bool canConvert1 = int.TryParse(Console.ReadLine(), out dia);

        if (canConvert1 == true)
        {
            if (dia > 0 && dia <=7) {
                switch (dia)
                {
                    case 1: Console.WriteLine("Lues");
                        break;
                    case 2: Console.WriteLine("Martes");
                        break;
                    case 3: Console.WriteLine("Miércoles");
                        break;
                    case 4: Console.WriteLine("Jueves");
                        break;
                    case 5: Console.WriteLine("Viernes");
                        break;
                    case 6: Console.WriteLine("Sábado");
                        break;
                    case 7: Console.WriteLine("Domingo");
                        break;
                }            
            } else
            {
                Console.WriteLine("No es un día de la semana");
            }
        } else
        {
            Console.WriteLine("No es un día de la semana");
        }
    }
}