﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_FORMS_JPSE_1057623
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cmbseleccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbSeleccion.SelectedIndex)
            {
                case 0:
                    MessageBox.Show("SUMATORIA");
                    tabControl1.SelectedTab = tabPage1;
                    break;
                case 1:
                    MessageBox.Show("TABLAS DE MULTIPLICAR");
                    tabControl1.SelectedTab = tabPage2;
                    break;
                case 2:
                    MessageBox.Show("NÚMERO PERFECTO");
                    tabControl1.SelectedTab = tabPage3;
                    break;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblIngrese_Click(object sender, EventArgs e)
        {

        }

        private void lblRes_Click(object sender, EventArgs e)
        {

        }

        private void txtNumero_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnSeleccion_Click(object sender, EventArgs e)
        {
            switch (cmbSeleccion.SelectedIndex)
            {
                case 0:
                    int inicio = 0;
                    int suma = 0;
                    int numero = 0;
                    bool prueba = int.TryParse(txtNumero.Text, out numero);
                    if (prueba == true && numero > 0)
                    {
                        do
                        {
                            inicio++;
                            suma = suma + inicio;
                        } while (inicio < numero);
                        lblRes.Text = suma.ToString();
                    } else
                    {
                        lblRes.Text = ("Ingrese un número mayor a 0 o un número válido");
                    }
                    break;
                case 1:
                    int factor = int.Parse(textBoxTablas.Text);
                    int multi = 0;
                    bool prueba1 = int.TryParse(textBoxTablas.Text, out factor);
                    if (prueba1 == true)
                    {
                        for (int i = 1; i <= 10; i++)
                        {
                            multi = factor * i;
                            lstbxTablas.Items.Add(factor + " * " + i + " = " + multi);
                        }
                    } else
                    {
                        lstbxTablas.Items.Add("Ingrese un número válido");
                    }
                    break;
                case 2:

                    int perfect = 0;
                    int sum = 0;

                    bool prueba2 = int.TryParse(txtbxNumPerf.Text, out perfect);
                    if (prueba2 == true)
                    {
                        if (perfect > 0)
                        {
                            for (int n = 1; n < perfect; n++)
                            {
                                if (perfect % n == 0)
                                {
                                    sum = sum + n;
                                }
                            }
                            if (sum == perfect)
                            {
                                lblNumPerf.Text = (perfect + " Es un número perfecto.");
                            }
                            else
                            {
                                lblNumPerf.Text = (perfect + " No es un número perfecto.");
                            }
                        }
                        else
                        {
                            lblNumPerf.Text = ("ERROR! No es un número mayor a 0.");
                        }
                    }
                    else
                    {
                        lblNumPerf.Text = ("ERROR! No es número.");
                    }
                    break;
            }
            
        }

        private void llstbxTablas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
    }
}
