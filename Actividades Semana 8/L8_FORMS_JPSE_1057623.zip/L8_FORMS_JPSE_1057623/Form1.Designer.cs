﻿namespace L8_FORMS_JPSE_1057623
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.laboratorio8 = new System.Windows.Forms.Label();
            this.gbSeleccionar = new System.Windows.Forms.GroupBox();
            this.cmbSeleccion = new System.Windows.Forms.ComboBox();
            this.btnSeleccion = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblRes = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblIngrese = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lstbxTablas = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxTablas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbxNumPerf = new System.Windows.Forms.TextBox();
            this.lblNumPerf = new System.Windows.Forms.Label();
            this.gbSeleccionar.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // laboratorio8
            // 
            this.laboratorio8.AutoSize = true;
            this.laboratorio8.Font = new System.Drawing.Font("MV Boli", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laboratorio8.Location = new System.Drawing.Point(401, 25);
            this.laboratorio8.Name = "laboratorio8";
            this.laboratorio8.Size = new System.Drawing.Size(205, 29);
            this.laboratorio8.TabIndex = 0;
            this.laboratorio8.Text = "LABORATORIO 8";
            this.laboratorio8.Click += new System.EventHandler(this.label1_Click);
            // 
            // gbSeleccionar
            // 
            this.gbSeleccionar.Controls.Add(this.cmbSeleccion);
            this.gbSeleccionar.Location = new System.Drawing.Point(33, 84);
            this.gbSeleccionar.Name = "gbSeleccionar";
            this.gbSeleccionar.Size = new System.Drawing.Size(467, 196);
            this.gbSeleccionar.TabIndex = 1;
            this.gbSeleccionar.TabStop = false;
            this.gbSeleccionar.Text = "Seleccionar";
            // 
            // cmbSeleccion
            // 
            this.cmbSeleccion.FormattingEnabled = true;
            this.cmbSeleccion.Items.AddRange(new object[] {
            "SUMATORIA",
            "TABLAS",
            "NÚMERO PERFECTO"});
            this.cmbSeleccion.Location = new System.Drawing.Point(6, 34);
            this.cmbSeleccion.Name = "cmbSeleccion";
            this.cmbSeleccion.Size = new System.Drawing.Size(455, 28);
            this.cmbSeleccion.TabIndex = 0;
            this.cmbSeleccion.SelectedIndexChanged += new System.EventHandler(this.cmbseleccion_SelectedIndexChanged);
            // 
            // btnSeleccion
            // 
            this.btnSeleccion.Location = new System.Drawing.Point(210, 303);
            this.btnSeleccion.Name = "btnSeleccion";
            this.btnSeleccion.Size = new System.Drawing.Size(120, 34);
            this.btnSeleccion.TabIndex = 2;
            this.btnSeleccion.Text = "Seleccionar";
            this.btnSeleccion.UseVisualStyleBackColor = true;
            this.btnSeleccion.Click += new System.EventHandler(this.btnSeleccion_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(527, 93);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(433, 187);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblRes);
            this.tabPage1.Controls.Add(this.txtNumero);
            this.tabPage1.Controls.Add(this.lblResultado);
            this.tabPage1.Controls.Add(this.lblIngrese);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(425, 154);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sumatoria";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // lblRes
            // 
            this.lblRes.AutoSize = true;
            this.lblRes.Location = new System.Drawing.Point(143, 54);
            this.lblRes.Name = "lblRes";
            this.lblRes.Size = new System.Drawing.Size(0, 20);
            this.lblRes.TabIndex = 4;
            this.lblRes.Click += new System.EventHandler(this.lblRes_Click);
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(135, 7);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(272, 26);
            this.txtNumero.TabIndex = 3;
            this.txtNumero.TextChanged += new System.EventHandler(this.txtNumero_TextChanged);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(7, 54);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(82, 20);
            this.lblResultado.TabIndex = 2;
            this.lblResultado.Text = "Resultado";
            this.lblResultado.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblIngrese
            // 
            this.lblIngrese.AutoSize = true;
            this.lblIngrese.Location = new System.Drawing.Point(7, 7);
            this.lblIngrese.Name = "lblIngrese";
            this.lblIngrese.Size = new System.Drawing.Size(121, 20);
            this.lblIngrese.TabIndex = 0;
            this.lblIngrese.Text = "Ingrese número";
            this.lblIngrese.Click += new System.EventHandler(this.lblIngrese_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBoxTablas);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.lstbxTablas);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(425, 154);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tablas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lblNumPerf);
            this.tabPage3.Controls.Add(this.txtbxNumPerf);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(425, 154);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Número perfecto";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // lstbxTablas
            // 
            this.lstbxTablas.FormattingEnabled = true;
            this.lstbxTablas.ItemHeight = 20;
            this.lstbxTablas.Location = new System.Drawing.Point(6, 46);
            this.lstbxTablas.Name = "lstbxTablas";
            this.lstbxTablas.Size = new System.Drawing.Size(413, 104);
            this.lstbxTablas.TabIndex = 0;
            this.lstbxTablas.SelectedIndexChanged += new System.EventHandler(this.llstbxTablas_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese número";
            // 
            // textBoxTablas
            // 
            this.textBoxTablas.Location = new System.Drawing.Point(147, 6);
            this.textBoxTablas.Name = "textBoxTablas";
            this.textBoxTablas.Size = new System.Drawing.Size(272, 26);
            this.textBoxTablas.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ingrese número";
            // 
            // txtbxNumPerf
            // 
            this.txtbxNumPerf.Location = new System.Drawing.Point(150, 3);
            this.txtbxNumPerf.Name = "txtbxNumPerf";
            this.txtbxNumPerf.Size = new System.Drawing.Size(272, 26);
            this.txtbxNumPerf.TabIndex = 5;
            // 
            // lblNumPerf
            // 
            this.lblNumPerf.AutoSize = true;
            this.lblNumPerf.Location = new System.Drawing.Point(212, 67);
            this.lblNumPerf.Name = "lblNumPerf";
            this.lblNumPerf.Size = new System.Drawing.Size(0, 20);
            this.lblNumPerf.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(994, 399);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnSeleccion);
            this.Controls.Add(this.gbSeleccionar);
            this.Controls.Add(this.laboratorio8);
            this.Name = "Form1";
            this.Text = "LABORATORIO 8";
            this.gbSeleccionar.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label laboratorio8;
        private System.Windows.Forms.GroupBox gbSeleccionar;
        private System.Windows.Forms.ComboBox cmbSeleccion;
        private System.Windows.Forms.Button btnSeleccion;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblIngrese;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Label lblRes;
        private System.Windows.Forms.ListBox lstbxTablas;
        private System.Windows.Forms.TextBox textBoxTablas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNumPerf;
        private System.Windows.Forms.TextBox txtbxNumPerf;
        private System.Windows.Forms.Label label2;
    }
}

