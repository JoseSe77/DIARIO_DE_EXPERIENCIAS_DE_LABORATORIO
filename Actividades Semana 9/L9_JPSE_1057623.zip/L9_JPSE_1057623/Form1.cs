﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_JPSE_1057623
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        automovil myAutomovil = new automovil();

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardarInfo_Click(object sender, EventArgs e)
        {
            myAutomovil.definirPrecio(Convert.ToDouble(txtbxPrecio.Text));
            myAutomovil.definirModelo(Convert.ToInt32(txtbxModelo.Text));
            myAutomovil.definirMarca(txtbxMarca.Text);
            myAutomovil.definirTipoCambio(Convert.ToDouble(txtbxTipoDeCambio.Text));
            MessageBox.Show("Los datos se guardaron correctamente");
            txtbxDatosAutomovil.Text = myAutomovil.MostrarInformacion();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtbxTipoDeCambio_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtbxMarca.Clear();
            txtbxModelo.Clear();
            txtbxPrecio.Clear();
            txtbxDescuento.Clear();
            txtbxDatosAutomovil.Clear();
            txtbxTipoDeCambio.Clear();

        }

        private void tpAuto_Click(object sender, EventArgs e)
        {

        }

        private void txtbxDescuento_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAplicar_Click(object sender, EventArgs e)
        {
            myAutomovil.aplicarDescuento(Convert.ToDouble(txtbxDescuento.Text));
            txtbxDatosAutomovil.Text = myAutomovil.MostrarInformacion();
        }

        private void btnCambiarDisponibilidad_Click(object sender, EventArgs e)
        {
            myAutomovil.cambiarDisponibiliad(true);
            txtbxDatosAutomovil.Text = myAutomovil.MostrarInformacion();
        }
    }
}
