﻿namespace L9_JPSE_1057623
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLaboratorioConClases = new System.Windows.Forms.Label();
            this.tcIngresoDeDatos = new System.Windows.Forms.TabControl();
            this.tpDatos = new System.Windows.Forms.TabPage();
            this.btnGuardarInfo = new System.Windows.Forms.Button();
            this.txtbxTipoDeCambio = new System.Windows.Forms.TextBox();
            this.txtbxMarca = new System.Windows.Forms.TextBox();
            this.txtbxPrecio = new System.Windows.Forms.TextBox();
            this.txtbxModelo = new System.Windows.Forms.TextBox();
            this.lblTipoDeCambio = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblModelo = new System.Windows.Forms.Label();
            this.tpAuto = new System.Windows.Forms.TabPage();
            this.txtbxDescuento = new System.Windows.Forms.TextBox();
            this.lblDescuento = new System.Windows.Forms.Label();
            this.txtbxDatosAutomovil = new System.Windows.Forms.TextBox();
            this.btnCambiarDisponibilidad = new System.Windows.Forms.Button();
            this.btnAplicar = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.tcIngresoDeDatos.SuspendLayout();
            this.tpDatos.SuspendLayout();
            this.tpAuto.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLaboratorioConClases
            // 
            this.lblLaboratorioConClases.AutoSize = true;
            this.lblLaboratorioConClases.Location = new System.Drawing.Point(277, 28);
            this.lblLaboratorioConClases.Name = "lblLaboratorioConClases";
            this.lblLaboratorioConClases.Size = new System.Drawing.Size(231, 20);
            this.lblLaboratorioConClases.TabIndex = 0;
            this.lblLaboratorioConClases.Text = "LABORATORIO CON CLASES";
            // 
            // tcIngresoDeDatos
            // 
            this.tcIngresoDeDatos.Controls.Add(this.tpDatos);
            this.tcIngresoDeDatos.Controls.Add(this.tpAuto);
            this.tcIngresoDeDatos.Location = new System.Drawing.Point(203, 89);
            this.tcIngresoDeDatos.Name = "tcIngresoDeDatos";
            this.tcIngresoDeDatos.SelectedIndex = 0;
            this.tcIngresoDeDatos.Size = new System.Drawing.Size(408, 322);
            this.tcIngresoDeDatos.TabIndex = 1;
            // 
            // tpDatos
            // 
            this.tpDatos.Controls.Add(this.btnGuardarInfo);
            this.tpDatos.Controls.Add(this.txtbxTipoDeCambio);
            this.tpDatos.Controls.Add(this.txtbxMarca);
            this.tpDatos.Controls.Add(this.txtbxPrecio);
            this.tpDatos.Controls.Add(this.txtbxModelo);
            this.tpDatos.Controls.Add(this.lblTipoDeCambio);
            this.tpDatos.Controls.Add(this.lblMarca);
            this.tpDatos.Controls.Add(this.lblPrecio);
            this.tpDatos.Controls.Add(this.lblModelo);
            this.tpDatos.Location = new System.Drawing.Point(4, 29);
            this.tpDatos.Name = "tpDatos";
            this.tpDatos.Padding = new System.Windows.Forms.Padding(3);
            this.tpDatos.Size = new System.Drawing.Size(400, 289);
            this.tpDatos.TabIndex = 0;
            this.tpDatos.Text = "Ingreso De Datos";
            this.tpDatos.UseVisualStyleBackColor = true;
            this.tpDatos.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // btnGuardarInfo
            // 
            this.btnGuardarInfo.Location = new System.Drawing.Point(89, 188);
            this.btnGuardarInfo.Name = "btnGuardarInfo";
            this.btnGuardarInfo.Size = new System.Drawing.Size(146, 55);
            this.btnGuardarInfo.TabIndex = 8;
            this.btnGuardarInfo.Text = "GUARDAR INFORMACIÓN";
            this.btnGuardarInfo.UseVisualStyleBackColor = true;
            this.btnGuardarInfo.Click += new System.EventHandler(this.btnGuardarInfo_Click);
            // 
            // txtbxTipoDeCambio
            // 
            this.txtbxTipoDeCambio.Location = new System.Drawing.Point(201, 123);
            this.txtbxTipoDeCambio.Name = "txtbxTipoDeCambio";
            this.txtbxTipoDeCambio.Size = new System.Drawing.Size(100, 26);
            this.txtbxTipoDeCambio.TabIndex = 7;
            this.txtbxTipoDeCambio.TextChanged += new System.EventHandler(this.txtbxTipoDeCambio_TextChanged);
            // 
            // txtbxMarca
            // 
            this.txtbxMarca.Location = new System.Drawing.Point(201, 91);
            this.txtbxMarca.Name = "txtbxMarca";
            this.txtbxMarca.Size = new System.Drawing.Size(100, 26);
            this.txtbxMarca.TabIndex = 6;
            // 
            // txtbxPrecio
            // 
            this.txtbxPrecio.Location = new System.Drawing.Point(201, 56);
            this.txtbxPrecio.Name = "txtbxPrecio";
            this.txtbxPrecio.Size = new System.Drawing.Size(100, 26);
            this.txtbxPrecio.TabIndex = 5;
            // 
            // txtbxModelo
            // 
            this.txtbxModelo.Location = new System.Drawing.Point(201, 20);
            this.txtbxModelo.Name = "txtbxModelo";
            this.txtbxModelo.Size = new System.Drawing.Size(100, 26);
            this.txtbxModelo.TabIndex = 4;
            // 
            // lblTipoDeCambio
            // 
            this.lblTipoDeCambio.AutoSize = true;
            this.lblTipoDeCambio.Location = new System.Drawing.Point(19, 130);
            this.lblTipoDeCambio.Name = "lblTipoDeCambio";
            this.lblTipoDeCambio.Size = new System.Drawing.Size(116, 20);
            this.lblTipoDeCambio.TabIndex = 3;
            this.lblTipoDeCambio.Text = "Tipo de cambio";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(19, 91);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(53, 20);
            this.lblMarca.TabIndex = 2;
            this.lblMarca.Text = "Marca";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Location = new System.Drawing.Point(19, 56);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(53, 20);
            this.lblPrecio.TabIndex = 1;
            this.lblPrecio.Text = "Precio";
            // 
            // lblModelo
            // 
            this.lblModelo.AutoSize = true;
            this.lblModelo.Location = new System.Drawing.Point(19, 20);
            this.lblModelo.Name = "lblModelo";
            this.lblModelo.Size = new System.Drawing.Size(61, 20);
            this.lblModelo.TabIndex = 0;
            this.lblModelo.Text = "Modelo";
            // 
            // tpAuto
            // 
            this.tpAuto.Controls.Add(this.txtbxDescuento);
            this.tpAuto.Controls.Add(this.lblDescuento);
            this.tpAuto.Controls.Add(this.txtbxDatosAutomovil);
            this.tpAuto.Controls.Add(this.btnCambiarDisponibilidad);
            this.tpAuto.Controls.Add(this.btnAplicar);
            this.tpAuto.Location = new System.Drawing.Point(4, 29);
            this.tpAuto.Name = "tpAuto";
            this.tpAuto.Padding = new System.Windows.Forms.Padding(3);
            this.tpAuto.Size = new System.Drawing.Size(400, 289);
            this.tpAuto.TabIndex = 1;
            this.tpAuto.Text = "Datos Automóvil";
            this.tpAuto.UseVisualStyleBackColor = true;
            this.tpAuto.Click += new System.EventHandler(this.tpAuto_Click);
            // 
            // txtbxDescuento
            // 
            this.txtbxDescuento.Location = new System.Drawing.Point(11, 31);
            this.txtbxDescuento.Name = "txtbxDescuento";
            this.txtbxDescuento.Size = new System.Drawing.Size(100, 26);
            this.txtbxDescuento.TabIndex = 4;
            this.txtbxDescuento.TextChanged += new System.EventHandler(this.txtbxDescuento_TextChanged);
            // 
            // lblDescuento
            // 
            this.lblDescuento.AutoSize = true;
            this.lblDescuento.Location = new System.Drawing.Point(7, 7);
            this.lblDescuento.Name = "lblDescuento";
            this.lblDescuento.Size = new System.Drawing.Size(87, 20);
            this.lblDescuento.TabIndex = 3;
            this.lblDescuento.Text = "Descuento";
            // 
            // txtbxDatosAutomovil
            // 
            this.txtbxDatosAutomovil.Location = new System.Drawing.Point(79, 90);
            this.txtbxDatosAutomovil.Multiline = true;
            this.txtbxDatosAutomovil.Name = "txtbxDatosAutomovil";
            this.txtbxDatosAutomovil.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtbxDatosAutomovil.Size = new System.Drawing.Size(222, 116);
            this.txtbxDatosAutomovil.TabIndex = 2;
            // 
            // btnCambiarDisponibilidad
            // 
            this.btnCambiarDisponibilidad.Location = new System.Drawing.Point(126, 212);
            this.btnCambiarDisponibilidad.Name = "btnCambiarDisponibilidad";
            this.btnCambiarDisponibilidad.Size = new System.Drawing.Size(165, 65);
            this.btnCambiarDisponibilidad.TabIndex = 1;
            this.btnCambiarDisponibilidad.Text = "CAMBIAR DISPONIBILIDAD";
            this.btnCambiarDisponibilidad.UseVisualStyleBackColor = true;
            this.btnCambiarDisponibilidad.Click += new System.EventHandler(this.btnCambiarDisponibilidad_Click);
            // 
            // btnAplicar
            // 
            this.btnAplicar.Location = new System.Drawing.Point(254, 24);
            this.btnAplicar.Name = "btnAplicar";
            this.btnAplicar.Size = new System.Drawing.Size(82, 33);
            this.btnAplicar.TabIndex = 0;
            this.btnAplicar.Text = "Aplicar";
            this.btnAplicar.UseVisualStyleBackColor = true;
            this.btnAplicar.Click += new System.EventHandler(this.btnAplicar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(668, 319);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(87, 34);
            this.btnLimpiar.TabIndex = 2;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(668, 377);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(87, 34);
            this.btnSalir.TabIndex = 3;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.tcIngresoDeDatos);
            this.Controls.Add(this.lblLaboratorioConClases);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tcIngresoDeDatos.ResumeLayout(false);
            this.tpDatos.ResumeLayout(false);
            this.tpDatos.PerformLayout();
            this.tpAuto.ResumeLayout(false);
            this.tpAuto.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLaboratorioConClases;
        private System.Windows.Forms.TabControl tcIngresoDeDatos;
        private System.Windows.Forms.TabPage tpDatos;
        private System.Windows.Forms.TabPage tpAuto;
        private System.Windows.Forms.Button btnGuardarInfo;
        private System.Windows.Forms.TextBox txtbxTipoDeCambio;
        private System.Windows.Forms.TextBox txtbxMarca;
        private System.Windows.Forms.TextBox txtbxPrecio;
        private System.Windows.Forms.TextBox txtbxModelo;
        private System.Windows.Forms.Label lblTipoDeCambio;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblModelo;
        private System.Windows.Forms.TextBox txtbxDescuento;
        private System.Windows.Forms.Label lblDescuento;
        private System.Windows.Forms.TextBox txtbxDatosAutomovil;
        private System.Windows.Forms.Button btnCambiarDisponibilidad;
        private System.Windows.Forms.Button btnAplicar;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
    }
}

