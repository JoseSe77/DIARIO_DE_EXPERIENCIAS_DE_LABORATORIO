﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_JPSE_1057623
{
    public class automovil
    {

        private int modelo;
        private double precio, tipoCambioDolar, descuentoAplicado;
        private string marca;
        private bool disponible;

        public int Modelo { get{ return modelo; } }
        public double Precio { get{ return precio; } }
        public double TipoCambioDolar { get { return tipoCambioDolar; } }
        public double DescuentoAplicado { get{ return descuentoAplicado; } }
        public string Marca { get{ return marca; } }

        public automovil()
        {
            modelo = 2019;
            precio = 0;
            marca = string.Empty; //o " ";
            disponible = false;
            tipoCambioDolar = 0;
            descuentoAplicado = 0;
        }
        public void definirModelo(int unModelo)
        {
            modelo = unModelo;
        }
        public void definirPrecio(double unPrecio)
        {
            precio = unPrecio;
        }
        public void definirMarca(string unaMarca)
        {
            marca = unaMarca;
        }
        public void definirTipoCambio(double unTipoCambio)
        {
            tipoCambioDolar = unTipoCambio;
        }
        public void cambiarDisponibiliad(bool Disponible)
        {
            disponible = Disponible;

            if (disponible)
            {
                disponible = true;
            } else
            {
                disponible = false;
            }
        }
        public string mostrarDisponibilidad() //métodos o funciones
        {
            if (disponible)
            {
                return "No se encuentra disponible actualmente";
            }
            else
            {
                return "Disponible";
            }
        }

        private double Conversion()
        {
            return precio / tipoCambioDolar;
        }
        public string MostrarInformacion()
        {
            return $"Marca: {marca}.\r\nModelo: {modelo}.\r\nPrecio de venta: Q{precio}.\r\nPrecio en dólares: ${Conversion()}.\r\n{mostrarDisponibilidad()}.";
        }
        public void aplicarDescuento(double miDescuento)
        {
            descuentoAplicado = miDescuento;
            double nuevoPrecio = precio - descuentoAplicado;
            definirPrecio(nuevoPrecio);
            Conversion();
        }
    }
}