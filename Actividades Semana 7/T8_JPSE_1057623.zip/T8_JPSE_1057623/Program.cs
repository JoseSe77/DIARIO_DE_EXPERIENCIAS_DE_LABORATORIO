﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography.X509Certificates;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("LABORATORIO 8 - José Pablo Sosa España - 1057623");

        string opcion = "0";
        while(opcion == "0")
        {
            Console.WriteLine("\nIngrese una opción: \n");
            Console.WriteLine("a. Sumatoria");
            Console.WriteLine("b. Mostrar tablas de multiplicar");
            Console.WriteLine("c. Número Perfecto");
            Console.WriteLine("d. Salir del menú");

            opcion = Console.ReadLine();
            switch (opcion)
            {
                case ("a"):
                    Console.Clear();
                    Console.WriteLine("Sumatoria\n");

                    int inicio = 0;
                    int suma = 0;
                    Console.WriteLine("Ingrese un número");
                    int numero = Convert.ToInt32(Console.ReadLine());
                    Console.Clear();

                    do
                    {
                        inicio++;
                        Console.WriteLine(inicio);
                        suma = suma + inicio;
                    } while (inicio < numero);
                    Console.WriteLine("La sumatoria es: " + suma);
                    opcion = "0";
                    break;

                case ("b"):
                    Console.Clear();
                    Console.WriteLine("Mostrar tablas de multiplicar\n");

                    Console.WriteLine("Ingrese el número que desea multiplicar: ");
                    int factor = Convert.ToInt32(Console.ReadLine());
                    int multi = 0;
                    Console.Clear();

                    for (int i = 1; i <= 10; i++)
                    {
                        multi = factor * i;
                        Console.WriteLine(factor + "*" + i + "=" + multi);
                    }
                    opcion = "0";
                    break;

                case ("c"):
                    Console.Clear();
                    Console.WriteLine("Número perfecto\n");

                    int perfect = 0;
                    Console.WriteLine("Ingrese un número entero: ");
                    int sum = 0;

                    bool prueba = int.TryParse(Console.ReadLine(), out perfect);
                    if (prueba == true) {
                        if (perfect > 0)
                        {
                            for (int n = 1; n < perfect; n++)
                            {
                                if (perfect % n == 0)
                                {
                                    sum = sum + n;
                                }
                            }
                            if (sum == perfect)
                            {
                                Console.WriteLine("Es un número perfecto.");
                            }
                            else
                            {
                                Console.WriteLine("No es un número perfecto.");
                            }
                        } else
                        {
                            Console.WriteLine("ERROR! No es un número mayor a 0.");
                        }
                    } else
                    {
                        Console.WriteLine("ERROR! No es número.");
                    }
                    opcion = "0";
                    break;

                case ("d"):
                    opcion = "1";
                    Console.Clear();
                    Console.WriteLine("Hasta pronto\n");
                    break;

                default:
                    Console.Clear();
                    Console.WriteLine("Esa no es una opcion del menú.");
                    opcion = "0";
                    break;
            }
        }
    }
}

