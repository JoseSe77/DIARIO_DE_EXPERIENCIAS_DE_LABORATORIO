﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1: operaciones aritméticas");
        double numero1;
        double numero2;

        Console.WriteLine("\nIngrese el primer número: ");
        numero1 = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("\nIngrese el segundo número: ");
        numero2 = Convert.ToDouble(Console.ReadLine());

        double suma;
        suma = numero1 + numero2;
        Console.WriteLine("\nSuma: " + numero1 + " + " + numero2 + " = " + suma);

        double resta;
        resta = numero1 - numero2;
        Console.WriteLine("Resta: " + numero1 + " - " + numero2 + " = " + resta);

        double multiplicacion;
        multiplicacion = numero1 * numero2;
        Console.WriteLine("Multiplicación: " + numero1 + " * " + numero2 + " = " + multiplicacion);

        double division;
        division = numero1 / numero2;
        Console.WriteLine("División: " + numero1 + " / " + numero2 + " = " + division);

        double div;
        div = numero1 / numero2;
        Console.WriteLine("Div: " + numero1 + " / " + numero2 + " = " + div);

        double mod;
        mod = numero1 % numero2;
        Console.WriteLine("Mod: " + numero1 + " % " + numero2 + " = " + mod);

        Console.WriteLine("\n\nEjercicio 2: operaciones booleanas");

        if (numero1 > numero2)
        {
            Console.WriteLine("\nNúmero 1: " + numero1 + " > " + "Número 2: " + numero2);
        }
        else if (numero1 < numero2)
        {
            Console.WriteLine("\nNúmero 1: " + numero1 + " < " + "Número 2: " + numero2);
        }
        else if (numero1 == numero2)
        {
            Console.WriteLine("\nNúmero 1: " + numero1 + " = " + "Número 2: " + numero2);
        }
    }
}
